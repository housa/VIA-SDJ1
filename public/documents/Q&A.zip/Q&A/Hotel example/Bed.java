public class Bed {

	private String type;
	
	public Bed(String type) {
		this.type = type;
	}
	
	public boolean isSingle() {
		return type.equals("single");
		//boolean b = type.equals("single");
		//if(b == true) {
		//	return true;
		//}
		//else {
		//	return false;
		//}
	}
	
	public boolean isDouble() {
		return type.equals("double");
	}
	
	public boolean isKingSize() {
		return type.equals("kingSize");
	}
}
