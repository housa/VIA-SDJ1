import java.util.ArrayList;

public class Hotel {

	private String name;
	private ArrayList<Room> rooms;
	
	public Hotel(String name, Room[] rooms) {
		this.name = name;
		this.rooms = new ArrayList<Room>();
		for(int i = 0; i < rooms.length; i++) {
			this.rooms.add(rooms[i]);
		}
		//this.rooms = rooms; if the field rooms had type Room[]
	}
	
	public String getName() {
		return name;
	}
	
	public int getNumberOfRooms() {
		return rooms.size();
	}
	
	public int getNumberOfAvailableRooms() {
		int counter = 0;
		for(int i = 0; i < rooms.size(); i++) {
			if(!(rooms.get(i).isOccupied())) {
				counter++;
			}
		}
		return counter;
	}
	
	public Room getFirstAvailableRoom() {
		for(int i = 0; i < rooms.size(); i++) {
			Room room = rooms.get(i);
			if(!room.isOccupied()) {
				return room;
			}
		}
		return null;
	}
	
	public Room getFirstAvailableRoom(double maxPrice) {
		if(maxPrice < 59.50) {
			return null;
		}
		for(int i = 0; i < rooms.size(); i++) {
			Room room = rooms.get(i);
			double price = room.getPrice();
			if(!room.isOccupied() && price <= maxPrice) {
				return room;
			}
		}
		return null;
	}
	
	public Room[] getAvailableRooms(String bedType) {
		// The easy (and much better and correct) way to solve the exercise.
		ArrayList<Room> result = new ArrayList<Room>();
		for(int i = 0; i < rooms.size(); i++) {
			Room room = rooms.get(i);
			boolean available = !room.isOccupied();
			boolean correctBedType = room.getBedType().equals(bedType);
			if(available && correctBedType) {
				result.add(room);
			}
		}
		Room[] r = new Room[result.size()];
		return result.toArray(r);
	}
	// The basic idea is 
	// 1. creating a new ArrayList containing the elements living up to the criteria
	// 2. convert the new ArrayList to an array using the toArray method
	
	public boolean hasGuest(Guest guest) {
		for(int i = 0; i < rooms.size(); i++) {
			if(rooms.get(i).equals(guest)) {
				//if the guest in question is in the room we look no further and return true
				return true;
			}
		}
		//if we've reached the end of the loop without finding the guest we return false
		return false;
	}
	
	public Room getRoom(Guest guest) {
		for(int i = 0; i < rooms.size(); i++) {
			if(rooms.get(i).getGuest().equals(guest)) {
				//if the guest in question is in the room we look no further and return the room
				return rooms.get(i);
			}
		}
		//if we've reached the end of the loop without finding the guest we return null, 
		//since there is no room with that particular guest
		return null;
	}
}
