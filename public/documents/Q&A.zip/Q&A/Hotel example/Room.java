public class Room {

	private int number;
	private Guest guest;
	private Bed bed;
	
	public Room(int number, String bedType) {
		this.number = number;
		this.guest = null;
		this.bed = new Bed(bedType);
	}
	
	public int getNumber() {
		return number;
	}
	
	public int getFloor() {
		int floor = number / 100;
		return floor;
	}
	
	public double getPrice() {
		if(bed.isSingle()) {
			return 59.50;
		}
		else if(bed.isDouble()) {
			return 72.40;
		}
		else if(bed.isKingSize()) {
			return 89.00;
		}
		else {
			return 0.0;
		}
	}
	
	public boolean isOccupied() {
		if(guest == null) {
			return false;
		}
		else {
			return true;
		}
	}
	
	public void registerGuest(Guest guest) {
		this.guest = guest;
	}
	
	public void vacate() {
		guest = null;
	}
	
	public String getBedType() {
		if(bed.isSingle()) {
			return "single";
		}
		else if(bed.isDouble()) {
			return "double";
		}
		else {
			return "kingSize";
		}
	}
	
	public Guest getGuest() {
		return guest;
	}
	
	public String toString() {
		String s = "Room number " + number + " costs $" + getPrice() + ", currently ";
		String p;
		if(isOccupied()) {
			p = "occupied";
		}
		else {
			p = "available";
		}
		return s +p;
	}
}
