public class Test {

	public static void main(String[] args) {
		Guest alexandra = new Guest("Alexandra");
		Guest lukas = new Guest("Lukas");
		Room room1 = new Room(103, "single");
		Room room2 = new Room(206, "double");
		Room[] rooms = {room1, room2};
		Hotel hotel = new Hotel("The best hotel in the world", rooms);
		
		//this should be 2
		System.out.println(hotel.getNumberOfAvailableRooms());
		//we put a guest in the first available room
		hotel.getFirstAvailableRoom().registerGuest(alexandra);
		//this should be 1 now
		System.out.println(hotel.getNumberOfAvailableRooms());
		//we put a guest in the first available room that costs less than $80
		hotel.getFirstAvailableRoom(80.00).registerGuest(lukas);
		//this should be 0 now
		System.out.println(hotel.getNumberOfAvailableRooms());
		//we print the room Alexandra is in
		System.out.println(hotel.getRoom(alexandra));
		//we print the room Lukas is in
		System.out.println(hotel.getRoom(lukas));
		//feel free to test the rest of the functionality yourself
	}
}
