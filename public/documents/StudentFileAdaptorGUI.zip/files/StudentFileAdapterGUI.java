package files;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class StudentFileAdapterGUI extends JFrame
{ 	
	private JTabbedPane tabPane;
 
	private JPanel allStudentsPanel;
	private JPanel changeCountryPanel;
	private JPanel inputPanel;
 
	private JTextArea allStudentsArea;
	private JScrollPane allStudentsScrollPane;

	private JLabel firstNameLabel;
	private JLabel lastNameLabel;
	private JLabel countryLabel;

	private JTextField firstNameField;
	private JTextField lastNameField;
	private JTextField countryField;

	private JButton getButton;
	private JButton updateButton;
	
	private ButtonListener listener;
	
	private StudentFileAdaptor adaptor;

	public StudentFileAdapterGUI()
	{
		super("Student File Adapter GUI");

		listener = new ButtonListener();
		
		adaptor = new StudentFileAdaptor("students.bin");
		
		//The All Students panel
		allStudentsPanel = new JPanel();

		allStudentsArea = new JTextArea(20, 50);
		allStudentsScrollPane = new JScrollPane(allStudentsArea);
		allStudentsPanel.add(allStudentsScrollPane);

		getButton = new JButton("Get Students");
		getButton.addActionListener(listener);
		allStudentsPanel.add(getButton);

		//The Change Country panel
		changeCountryPanel = new JPanel();

		inputPanel = new JPanel();

		firstNameLabel = new JLabel("First Name:    ");
		firstNameField = new JTextField(15);
		inputPanel.add(firstNameLabel);
		inputPanel.add(firstNameField);
		
		lastNameLabel = new JLabel("Last Name:    ");
		lastNameField = new JTextField(15);
		inputPanel.add(lastNameLabel);
		inputPanel.add(lastNameField);
		
		countryLabel = new JLabel("Country:        ");
		countryField = new JTextField(15);
		inputPanel.add(countryLabel);
		inputPanel.add(countryField);
		
		updateButton = new JButton("Update");
		updateButton.addActionListener(listener);
		inputPanel.add(updateButton);	
		
		changeCountryPanel.add(inputPanel);
		inputPanel.setPreferredSize(new Dimension(300, 130));

		tabPane = new JTabbedPane();
		tabPane.addTab("All Students", allStudentsPanel);
		tabPane.addTab("Change Country", changeCountryPanel);

		add(tabPane);
		setSize(675, 430);
		setVisible(true);
		setResizable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}
	
	private class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == getButton) {
				StudentList list = adaptor.getAllStudents();
				String slist = list.toString();
				allStudentsArea.setText(slist);
			} else if(e.getSource() == updateButton) {
				String firstName = firstNameField.getText();
				String lastName = lastNameField.getText();
				String country = countryField.getText();
				adaptor.changeCountry(firstName, lastName, country);
				firstNameField.setText("");
				lastNameField.setText("");
				countryField.setText("");
			}
			
		}
		
	}

	public static void main(String[] args)
	{
		StudentFileAdapterGUI sfagui = new StudentFileAdapterGUI();
	}
}
