package files;

import java.io.*;

public class StudentFileAdaptor {

	private String fileName;
	private MyFileIO myFileIO;
	
	public StudentFileAdaptor(String fileName) {
		this.fileName = fileName;
		myFileIO = new MyFileIO();
	}
	
	public StudentList getAllStudents() {
		StudentList result = null;
		try {
			result = (StudentList)myFileIO.readObjectFromFile(fileName);
		}
		catch(FileNotFoundException e) {
			System.out.println("File could not be found");
		} 
		catch(IOException e) {
			e.printStackTrace();
			System.out.println("Could not read from file");
		} 
		catch(ClassNotFoundException e) {
			System.out.println("Class not found");
		}
		catch(ClassCastException e) {
			System.out.println("File does not contain students");
		}
		return result;
	}
	
	public StudentList getStudentsFromCountry(String fromCountry) {
		StudentList initial = getAllStudents();
		StudentList result = new StudentList();
		for(int i = 0; i < initial.size(); i++) {
			Student s = initial.get(i);
			if(fromCountry.equals(s.getCountry())) {
				result.add(s);
			}
		}
		return result;
	}
	
	public void saveStudents(StudentList students) {
		try {
			myFileIO.writeToFile(fileName, students);
		}
		catch (FileNotFoundException e) {
			System.out.println("File not found");
		}
		catch (IOException e) {
			System.out.println("Could not write to file");
		}
	}
	
	public void changeCountry(String firstName, String lastName, String country) {
		StudentList students = getAllStudents();
		int studentIndex = students.getIndex(firstName, lastName);
		if(studentIndex > 0 && studentIndex < students.size()) {
			students.get(studentIndex).setCountry(country);
		}
		else {
			System.out.println("The student is not in the system");
		}
		
		saveStudents(students);
	}
	
	
}
