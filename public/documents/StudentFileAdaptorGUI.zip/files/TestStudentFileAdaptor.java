package files;

public class TestStudentFileAdaptor {

	public static void main(String[] args) {
		
		StudentFileAdaptor sfa = new StudentFileAdaptor("students.bin");
		
		//Get all students from the file and print them out
	    StudentList list = sfa.getAllStudents();
	    System.out.println("All students:\n" + list);
	    //Get all Romanian students from the file and print them out
	    list = sfa.getStudentsFromCountry("Romania");
	    System.out.println("Romanian students:\n" + list);
	    //Change country
	    sfa.changeCountry("Cristian", "Russu", "Moldova");
	    //Get all Romanian students from the file and print them out
	    list = sfa.getStudentsFromCountry("Romania");
	    System.out.println("Romanian students:\n" + list);
	    //Get all Moldovan students from the file and print them out
	    list = sfa.getStudentsFromCountry("Moldova");
	    System.out.println("Moldovan students:\n" + list);
	}
}
