package files;

import java.io.*;
import java.util.ArrayList;

public class MyFileIO {

	public void writeToFile(String fileName, Object obj) throws FileNotFoundException, IOException {
		FileOutputStream fileOut = new FileOutputStream(fileName);
		writeObject(fileOut, obj);
		fileOut.close();
	}
	
	public void writeToFile(String fileName, Object[] objs) throws FileNotFoundException, IOException {
		FileOutputStream fileOut = new FileOutputStream(fileName);
		for(int i = 0; i < objs.length; i++) {
			writeObject(fileOut, objs[i]);
		}
		fileOut.close();
	}
	
	private void writeObject(FileOutputStream fileOut, Object obj) throws IOException {
		ObjectOutputStream writer = new ObjectOutputStream(fileOut);
		writer.writeObject(obj);
	}
	
	public Object readObjectFromFile(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException {
		FileInputStream fileIn = new FileInputStream(fileName);
		ObjectInputStream reader = new ObjectInputStream(fileIn);
		Object o = reader.readObject();
		reader.close();
		return o;
	}
	
	public Object[] readArrayFromFile(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException {
		FileInputStream fileIn = new FileInputStream(fileName);
		ObjectInputStream reader = new ObjectInputStream(fileIn);
		ArrayList<Object> objs = new ArrayList<Object>();
		while(true) {
			try {
				objs.add(reader.readObject());
			}
			catch (EOFException e) {
				break;
			}
		}
		reader.close();
		return objs.toArray(new Object[objs.size()]);
	}
}
