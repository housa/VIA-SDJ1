package files;

import java.io.Serializable;
import java.util.ArrayList;

public class StudentList implements Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<Student> students;
	
	public StudentList() {
		students = new ArrayList<Student>();
	}
	
	public void add(Student student) {
		students.add(student);
	}
	
	public void setStudent(Student student, int index) {
		students.add(index,  student);
	}
	
	public Student get(int index) {
		return students.get(index);
	}
	
	public Student get(String firstName, String lastName) {
		for(int i = 0; i < students.size(); i++) {
			Student s = students.get(i);
			if(firstName.equals(s.getFirstName()) &&
					lastName.equals(s.getLastName())) {
				return s;
			}
		}
		return null;
	}
	
	public int getIndex(String firstName, String lastName) {
		for(int i = 0; i < students.size(); i++) {
			Student s = students.get(i);
			if(firstName.equals(s.getFirstName()) &&
					lastName.equals(s.getLastName())) {
				return i;
			}
		}
		return -1;
	}
	
	public int size() {
		return students.size();
	}
	
	public String toString() {
		String s = "";
		for(int i = 0; i < size(); i++) {
			s += get(i) + "\n";
		}
		return s;
	}
}
