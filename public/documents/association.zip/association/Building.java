package association;

public class Building {
    private Room livingRoom;

    public Building(Room livingRoom) {
        // The building and the room are intertwined, if we tear down the building we tear down the room.
        // So the life-span of the building and the room are alike and so the building and the room have a very tight
        // relationship. This is why it is a compositional relation (think of a building to be composited by the rooms 
        // it contains, in this case a building is a composition of a single living room)
        // 
        // Thus we "copy" the livingRoom in order to make sure that the Building has complete control over the 
        // livingRoom object
        this.livingRoom = livingRoom.copy();
    }
}
