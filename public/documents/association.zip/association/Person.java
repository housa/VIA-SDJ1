package association;

public class Person {
    private Sandwich sandwich;

    public Person(Sandwich sandwich) {
        // A Person "has a" sandwich, which is why we have an aggregation relationship, but if we eat the sandwich, or
        // kill the person, it does not impact the other. Thus we do _not_ have a compositional relation.
        //
        // There is little difference between aggregation and association however, so the implementation is the same.
        this.sandwich = sandwich;
    }
}
