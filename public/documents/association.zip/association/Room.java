package association;

public class Room {
    public Person owner;
    
    public Room(Person owner) {
        // A room has an owner, but doesn't own it or control it. The Room is thus "associated" with the owner.
        //
        // We don't copy the owner, as the relationship is loose.
        this.owner = owner;
    }
    
    public Room copy() {
        return new Room(owner);
    }
}
