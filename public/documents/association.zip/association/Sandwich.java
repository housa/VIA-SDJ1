package association;

public class Sandwich {
}
