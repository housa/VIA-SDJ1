package day16;

public class Car {

	private String make;
	private String model;
	private String colour;
	private Wheel wheel1;
	private Wheel wheel2;
	private Wheel wheel3;
	private Wheel wheel4;
	private Date manufactureDate;
	
	public Car(String make, String model, String colour, Date manufactureDate) {
		this.make = make;
		this.model = model;
		this.colour = colour;
		this.wheel1 = null;
		this.wheel2 = null;
		this.wheel3 = null;
		this.wheel4 = null;
		this.manufactureDate = manufactureDate.copy(); 
	}
	
	public String getMake() {
		return make;
	}
	
	public String getModel() {
		return model;
	}
	
	public String getColour() {
		return colour;
	}
	
	public void setColour(String colour) {
		this.colour = colour;
	}
	
	public Wheel getWheel(int position) {
		switch(position) {
		case 1:
			return wheel1;
		case 2:
			return wheel2;
		case 3:
			return wheel3;
		case 4:
			return wheel4;
		default:
			return null;
		}
	}
	
	public void setWheel(Wheel wheel, int position) {
		switch(position) {
		case 1:
			wheel1 = wheel;
			break;
		case 2:
			wheel2 = wheel;
			break;
		case 3: 
			wheel3 = wheel;
			break;
		case 4:
			wheel4 = wheel;
			break;
		}
	}
	
	public Date getManufactureDate() {
		return manufactureDate.copy();
	}
	
	public String toString() {
		return "make: " + make + " model: " + model + "manufacture date: " + manufactureDate + 
	               "\n Wheel 1: " + wheel1 + " Wheel 2: " + wheel2 
	               + " Wheel3 " + wheel3 + " Wheel4: " + wheel4;
		
	}
}
