package day16;

public class Date {
	
	private int day;
	private int month;
	private int year;
	
	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	public int getDay() {
		return day;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getYear() {
		return year;
	}
	
	public Date copy() {
		return new Date(day, month, year);
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Date)) {
			return false;
		}
		Date date = (Date)obj;
		if(date.getDay() == day && date.getMonth() == month 
				&& date.getYear() == year) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		return day + "/" + month + "/" + year;
	}
}
