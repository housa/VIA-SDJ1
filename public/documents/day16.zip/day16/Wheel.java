package day16;

public class Wheel {

	private int diameter;
	private int width;
	
	public Wheel(int diameter, int width) {
		this.diameter = diameter;
		this.width = width;
	}
	
	public int getDiameter() {
		return diameter;
	}
	
	public int getWidth() {
		return width;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Wheel)) {
			return false;
		}
		Wheel wheel = (Wheel)obj;
		if(wheel.getDiameter() == diameter && wheel.getWidth() == width) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		return "diameter: " + diameter + " width: " + width;
	}
}
