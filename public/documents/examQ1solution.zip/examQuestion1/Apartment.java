package examQuestion1;

public class Apartment extends Recidence {
    private int numberOfRooms;

    public Apartment(int number, double size, int numberOfRooms) {
        super(number, size, "Apartment");
        this.numberOfRooms = numberOfRooms;
    }

    @Override
    int getNumberOfRooms() {
        return numberOfRooms;
    }
}
