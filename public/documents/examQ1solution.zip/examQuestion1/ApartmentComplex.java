package examQuestion1;

import com.sun.org.apache.regexp.internal.RE;

import java.util.ArrayList;

public class ApartmentComplex {
    private String address;
    private ArrayList<Recidence> recidences;

    public ApartmentComplex(String address) {
        this.address = address;
        recidences = new ArrayList<Recidence>();
    }

    public int getNumberOfRecidences() {
        return recidences.size();
    }

    public void add(Recidence recidence) {
        recidences.add(recidence);
    }

    public Recidence getRecidence(int index) {
        if(index < recidences.size()) {
            return recidences.get(index);
        } else {
            return null;
        }
    }

    public Room getFirstAvailableRoom() {
        for(int i = 0; i < recidences.size(); i++) {
            Recidence r = recidences.get(i);
            if(r instanceof Room && r.isAvailable()) {
                return (Room)r;
            }
        }
        return null;
    }

    public Apartment getFirstAvailableApartment(int minNoOfRooms) {
        for(int i = 0; i < recidences.size(); i++) {
            Recidence r = recidences.get(i);
            if(r instanceof Apartment && r.isAvailable() && r.getNumberOfRooms() >= minNoOfRooms) {
                return (Apartment)r;
            }
        }
        return null;
    }
}
