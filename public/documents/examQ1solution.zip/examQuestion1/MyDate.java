package examQuestion1;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class MyDate {
    private int day;
    private int month;
    private int year;

    public MyDate(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public void set(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public MyDate copy() {
        MyDate date = new MyDate(day, month, year);
        return date;
    }

    public static MyDate now() {
        GregorianCalendar today = new GregorianCalendar();
        int d = today.get(Calendar.DAY_OF_MONTH);
        //Monts are indexed so January is 0
        int m = today.get(Calendar.MONTH) + 1;
        int y = today.get(Calendar.YEAR);
        MyDate now = new MyDate(d, m, y);
        return now;
    }

    public boolean equals(Object date) {
        if(!(date instanceof MyDate)) {
            return false;
        } else {
            MyDate d = (MyDate)date;
            return (day == d.getDay() && month == d.getMonth() && year == d.getYear());
        }
    }
}
