package examQuestion1;

public class Room extends Recidence {

    public Room(int number, double size) {
        super(number, size, "Room");
    }

    @Override
    int getNumberOfRooms() {
        return 1;
    }
}
