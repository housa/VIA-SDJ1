package examQuestion1;

import java.util.Date;

public class Test {
    public static void main(String[] args) {
        Tenant alex = new Tenant("Alexandra");
        Tenant lukas = new Tenant("Lukas");

        Room r1 = new Room(2, 10);
        Room r2 = new Room(4, 10);
        Apartment a1 = new Apartment(1, 50, 2);
        Apartment a2 = new Apartment(3, 70, 3);

        ApartmentComplex building1 = new ApartmentComplex("Aarhus");

        //Testing the Tenant class
        System.out.println("Test 1: " + (lukas.getName().equals("Lukas")));
        System.out.println("Test 2: " + (lukas.getRentedFrom()==null));
        lukas.setRentedFrom(MyDate.now());
        System.out.println("Test 3: " + (lukas.getRentedFrom().equals(MyDate.now())));

        //Testing the Recidence class
        System.out.println("Test 4: " + (a1.getNumber()==1));
        System.out.println("Test 5: " + (r1.getSize()==10));
        System.out.println("Test 6: " + (a2.getNumberOfRooms()==3));
        System.out.println("Test 7: " + (r2.getNumberOfRooms()==1));
        System.out.println("Test 8: " + (r1.getType().equals("Room")));
        System.out.println("Test 9: " + (a1.getType().equals("Apartment")));
        System.out.println("Test 10: " + (r1.isAvailable()==true));
        r1.rentTo(lukas, new Date(Date.UTC(2017, 1, 15, 10, 0, 0)));
        System.out.println("Test 11: " + (r1.isAvailable()==false));
        System.out.println("Test 12: " + (r1.getTenant().getName().equals("Lukas")));

        //testing the apartmentComplex class
        building1.add(a1);
        building1.add(r1);

        System.out.println("Test 13: " + (building1.getNumberOfRecidences() == 2));

        building1.add(r2);
        building1.add(a2);

        System.out.println("Test 14: " + (building1.getNumberOfRecidences() == 4));
        System.out.println("Test 15: " + (building1.getFirstAvailableApartment(3)==a2));
        System.out.println("Test 16: " + (building1.getFirstAvailableRoom() == r2));
    }
}
