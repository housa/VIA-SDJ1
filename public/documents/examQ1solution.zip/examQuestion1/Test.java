package examQuestion1;

import java.util.Date;

public class Test {
    public static void main(String[] args) {
        Tenant alex = new Tenant("Alexandra");
        Tenant lukas = new Tenant("Lukas");

        Room r1 = new Room(2, 10);
        Room r2 = new Room(4, 10);
        Apartment a1 = new Apartment(1, 50, 2);
        Apartment a2 = new Apartment(3, 70, 3);

        ApartmentComplex building1 = new ApartmentComplex("Aarhus");

        //Testing the Tenant class
        System.out.println(lukas.getName().equals("Lukas"));
        System.out.println(lukas.getRentedFrom()==null);
        lukas.setRentedFrom(MyDate.now());
        System.out.println(lukas.getRentedFrom().equals(MyDate.now()));

        //Testing the Recidence class
        System.out.println(a1.getNumber()==1);
        System.out.println(r1.getSize()==10);
        System.out.println(a2.getNumberOfRooms()==3);
        System.out.println(r2.getNumberOfRooms()==1);
        System.out.println(r1.getType().equals("Room"));
        System.out.println(a1.getType().equals("Apartment"));
        System.out.println(r1.isAvailable()==true);
        r1.rentTo(lukas, new Date(Date.UTC(2017, 1, 15, 10, 0, 0)));
        System.out.println(r1.isAvailable()==false);
        System.out.println(r1.getTenant().getName().equals("Lukas"));

        //testing the apartmentComplex class
        building1.add(a1);
        building1.add(r1);

        System.out.println(building1.getNumberOfRecidences() == 2);

        building1.add(r2);
        building1.add(a2);

        System.out.println(building1.getNumberOfRecidences() == 4);
        System.out.println(building1.getFirstAvailableApartment(3)==a2);
        System.out.println(building1.getFirstAvailableRoom() == r2);

    }
}
