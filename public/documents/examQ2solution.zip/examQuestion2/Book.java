package examQuestion2;

public abstract class Book {
    private String title;
    private String isbn;

    public Book(String title, String isbn) {
        this.title = title;
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getIsbn() {
        return isbn;
    }

    abstract String getBookType();

    public String toString() {
        String s = "title: " + title + "\n" + "isbn: " + isbn;
        return s;
    }

    public boolean equals(Object obj) {
        if(!(obj instanceof Book)) {
            return false;
        }
        Book b = (Book)obj;
        if(b.getTitle().equals(title) && b.getIsbn().equals(isbn)) {
            return true;
        } else {
            return false;
        }
    }
}
