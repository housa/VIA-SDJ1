package examQuestion2;

import java.util.ArrayList;

public class BookList {
    private ArrayList<Book> books;

    public BookList() {
        books = new ArrayList<Book>();
    }

    public int getNumberOfBooks() {
        return books.size();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public Book getBook(int index) {
        try {
            return books.get(index);
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    public Book getBook(String isbn) {
        for(int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if(book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    public Book removeBook(int index) {
        Book book = books.remove(index);
        return book;
    }

    public int getIndexOfFirstPrintedBook() {
        for(int i = 0; i < books.size(); i++) {
            if(books.get(i) instanceof PrintedBook) {
                return i;
            }
        }
        return -1;
    }

    public int getNumberOfBooksByType(String type) {
        int counter = 0;
        for(int i = 0; i < books.size(); i++) {
            if(books.get(i).getBookType().equals(type)) {
                counter++;
            }
        }
        return counter;
    }

    public Book[] getBooksByType(String type) {
        ArrayList<Book> result = new ArrayList<Book>();
        for(int i = 0; i < books.size(); i++) {
            if(books.get(i).getBookType().equals(type)) {
                result.add(books.get(i));
            }
        }
        return result.toArray(new Book[result.size()]);
    }

    public EBook[] getAllEBooks() {
        ArrayList<EBook> result = new ArrayList<EBook>();
        for(int i = 0; i < books.size(); i++) {
            Book b = books.get(i);
            if(b instanceof EBook) {
                EBook eb = (EBook)b;
                result.add(eb);
            }
        }
        return result.toArray(new EBook[result.size()]);
    }

    public String toString() {
        String s = "List of books: \n";
        for(int i = 0; i < books.size(); i++) {
            s+= books.get(i).toString() + "\n";
        }
        return s;
    }

    public boolean equals(Object obj) {
        if(!(obj instanceof BookList)) {
            return false;
        }
        BookList bl = (BookList)obj;
        if(bl.getNumberOfBooks() != getNumberOfBooks()) {
            return false;
        }
        for(int i = 0; i < books.size(); i++) {
            if(!getBook(i).equals(bl.getBook(i))) {
                return false;
            }
        }
        return true;
    }
}
