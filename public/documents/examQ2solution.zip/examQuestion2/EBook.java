package examQuestion2;

public class EBook extends Book {
    private String url;

    public EBook(String url, String title, String isbn) {
        super(title, isbn);
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public String getBookType() {
        return "E-book";
    }

    @Override
    public String toString() {
        String s = "title: " + getTitle() + "\n" + "type: " + getBookType() + "\n" + "isbn: " + getIsbn();
        return s;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof EBook)) {
            return false;
        }
        EBook eb = (EBook)obj;
        if(eb.getTitle().equals(super.getTitle()) && eb.getIsbn().equals(super.getIsbn()) && eb.getBookType().equals(getBookType())) {
            return true;
        } else {
            return false;
        }
    }
}
