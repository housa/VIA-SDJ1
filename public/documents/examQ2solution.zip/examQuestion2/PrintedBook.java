package examQuestion2;

public class PrintedBook extends Book {
    private boolean isPaperBack;

    public PrintedBook(String title, String isbn, boolean paperback) {
        super(title, isbn);
        isPaperBack = paperback;
    }

    public boolean isPaperBack() {
        return isPaperBack;
    }

    @Override
    public String getBookType() {
        if(isPaperBack) {
            return "Paperback";
        } else {
            return "Hard cover";
        }
    }

    @Override
    public String toString() {
        String s = "title: " + getTitle() + "\n";
        if(isPaperBack) {
            s+= "type: " + "Paperback \n";
        } else {
            s+= "type: " + "Hard cover \n";
        }
        s += "isbn: " + getIsbn();
        return s;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof PrintedBook)) {
            return false;
        }
        PrintedBook pb = (PrintedBook)obj;
        if(pb.getTitle().equals(super.getTitle()) && pb.getIsbn().equals(super.getIsbn()) && pb.getBookType().equals(getBookType())) {
            return true;
        } else {
            return false;
        }
    }
}
