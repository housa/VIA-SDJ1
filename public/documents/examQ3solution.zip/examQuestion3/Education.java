package examQuestion3;

public abstract class Education {
    private String code;
    private String title;

    protected Education(String code, String title) {
        this.code = code;
        this.title = title;
    }

    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Education == false) {
            return false;
        }
        Education education = (Education) obj;
        return education.getCode().equals(this.code) && education.getTitle().equals(this.title);
    }

    @Override
    public String toString() {
        return "[Education, code: " + code + ", title: " + title + "]";
    }
}
