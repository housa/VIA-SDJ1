package examQuestion3;

public class Programme extends Education {
    private String level;

    protected Programme(String code, String title, String level) {
        super(code, title);
        this.level = level;
    }

    public String getLevel() {
        return level;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Programme == false) {
            return false;
        }
        Programme programme = (Programme) obj;
        return super.equals(obj) && programme.getLevel().equals(this.level);
    }

    @Override
    public String toString() {
        return "[School: " + super.toString() + ", level: " + level + "]";
    }
}
