package examQuestion3;

public class School extends Education {
    private String type;

    public static String INFANT_SCHOOL = "Infant School";
    public static String JUNIOR_SCHOOL = "Junior School";
    public static String SECONDARY_SCHOOL = "Secondary School";
    public static String HIGH_SCHOOL = "High School";

    protected School(String code, String title, String type) {
        super(code, title);
        this.type = type;
    }

    public String getSchoolType() {
        return type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof School == false) {
            return false;
        }
        School school = (School) obj;
        return super.equals(school) && school.getSchoolType().equals(this.type);
    }

    @Override
    public String toString() {
        return "[School: " + super.toString() + ", type: " + type + "]";
    }
}
