package examQuestion3;

public class Student {
    private String name;
    private Education education;

    public Student(String name, Education education) {
        this.name = name;
        this.education = education;
    }

    public String getName() {
        return name;
    }

    public Education getEducation() {
        return education;
    }

    public void changeEducation(Education education) {
        this.education = education;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Student == false) {
            return false;
        }
        Student student = (Student) obj;
        return student.name.equals(this.name) && student.getEducation().equals(this.education);
    }

    @Override
    public String toString() {
        return "[Student, name: " + name + ", education: " + education + "]";
    }
}
