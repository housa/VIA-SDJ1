package examQuestion3;

import java.util.ArrayList;

public class StudentList {
    private ArrayList<Student> students;
    // We won't need this! ArrayLists gives us this functionality 
    private int size;

    public StudentList() {
        students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public Student getStudent(int index) {
        return students.get(index);
    }

    public void removeStudent(Student student) {
        // This only works if Student has a equals method
        students.remove(student);
    }

    public int getNumberOfStudents() {
        return students.size();
    }

    public int getNumberOfStudentsByEducation(Education education) {
        int count = 0;
        for (int i = 0; i < students.size(); i++) {
            Student student = getStudent(i);
            if (student.getEducation().equals(education)) {
                count++;
            }
        }
        return count;
    }

    public Student[] getStudentsByEducation(Education education) {
        Student[] studentArray = new Student[getNumberOfStudentsByEducation(education)];
        int curIdx = 0;
        for (int i = 0; i < students.size(); i++) {
            Student student = getStudent(i);
            if (student.getEducation().equals(education)) {
                studentArray[curIdx] = student;
                curIdx++;
            }
        }

        return studentArray;
    }

    public int getNumberOfHighSchoolStudents() {
        int count = 0;
        for (int i = 0; i < students.size(); i++) {
            Student student = getStudent(i);
            if (student.getEducation() instanceof School) {
                School school = (School) student.getEducation();
                if (school.getSchoolType().equals(School.HIGH_SCHOOL)) {
                    count++;
                }
            }
        }
        return count;
    }

    // Don't implement this silly functionality
    private void doubleTheListCapacity() {
    }
}
