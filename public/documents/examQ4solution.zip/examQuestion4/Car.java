package examQuestion4;

public abstract class Car {
    private String licenseNo;
    private double price;
    private Customer rentedTo;
    
    protected Car(String licenseNo, double price) {
        this.licenseNo = licenseNo;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getLicenseNo() {
        return licenseNo;
    }
    
    public abstract String getType();

    public Customer getRentedTo() {
        return rentedTo;
    }

    public void setRentedTo(Customer rentedTo) {
        this.rentedTo = rentedTo;
    }
    
    public boolean isAvailable() {
        // We could use an if-statement here to say if (rentedTo == null) then true else false
        // But remember that "rentedTo == null" is a boolean statement, so it is a question which returns yes or no i.e.
        // it returns "true" or "false".
        return rentedTo == null;
    }
}
