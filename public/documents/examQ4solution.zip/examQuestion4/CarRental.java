package examQuestion4;

import java.util.ArrayList;

public class CarRental {
    private String companyName;
    private String address;
    private ArrayList<Car> cars;

    public CarRental(String companyName, String address) {
        this.companyName = companyName;
        this.address = address;
        cars = new ArrayList<Car>();
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getAddress() {
        return address;
    }

    public int getNumberOfCars() {
        return cars.size();
    }

    public Car getCar(int index) {
        return cars.get(index);
    }

    public void addCar(Car car) {
        cars.add(car);
    }

    public Car getCarByLicense(String licenseNo) {
        for (int i = 0; i < cars.size(); i++) {
            Car car = getCar(i);
            if (car.getLicenseNo().equals(licenseNo)) {
                return car;
            }
        }
        return null;
    }
    
    public SportsCar getAvailableSportsCar() {
        for (int i = 0; i < cars.size(); i++) {
            Car car = getCar(i);
            if (car instanceof  SportsCar && car.isAvailable()) {
                return (SportsCar)car;
            }
        }
        return null;
    }
    
    public Van getAvailableVan(int minCapacity) {
        for (int i = 0; i < cars.size(); i++) {
            Car car = getCar(i);
            if (car instanceof  Van && car.isAvailable()) {
                Van van = (Van)car;
                if(van.getCapacity() >= minCapacity) {
                    return van;
                }
            }
        }
        return null;
    }
}
