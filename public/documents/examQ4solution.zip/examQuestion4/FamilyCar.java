package examQuestion4;

public class FamilyCar extends Car {
    private int seats;
    
    protected FamilyCar(String licenseNo, double price, int seats) {
        super(licenseNo, price);
        this.seats = seats;
    }

    @Override
    public String getType() {
        return "FamilyCar";
    }

    public int getSeats() {
        return seats;
    }
}
