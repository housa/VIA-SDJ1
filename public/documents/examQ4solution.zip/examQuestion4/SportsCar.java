package examQuestion4;

public class SportsCar extends Car {
    protected SportsCar(String licenseNo, double price) {
        super(licenseNo, price);
    }

    @Override
    public String getType() {
        return "SportsCar";
    }
}
