package examQuestion4;

public class Van extends Car {
    private int capacity;
    
    protected Van(String licenseNo, double price, int capacity) {
        super(licenseNo, price);
        this.capacity = capacity;
    }

    @Override
    public String getType() {
        return "Van";
    }

    public int getCapacity() {
        return capacity;
    }
}
