package exercise3401;

import java.util.ArrayList;

public class Bus {
    private ArrayList<Seat> seats;

    public Bus(Seat[] seats) {
        this.seats = new ArrayList<Seat>();
        for(int i = 0; i < seats.length; i++) {
            this.seats.add(seats[i]);
        }
    }

    public int getNumberOfSeats() {
        return seats.size();
    }

    /* the main idea for this method is to replace the seat with the given seatNumber,
     * remember this is to be seen as the id of that specific seat, not the order
     * the seats have in the bus, so we first need to find the given seat, then
     * replace it.
     */
    public void replaceSeat(int seatNumber, Seat seat) {
        for(int i = 0; i < seats.size(); i++) {
            if(seats.get(i).seatNumber == seatNumber) {
                seats.set(i, seat);
            }
        }
    }

    public Seat getSeat(int seatNumber) {
        for(int i = 0; i < seats.size(); i++) {
            if(seats.get(i).seatNumber == seatNumber) {
                return seats.get(i);
            }
        }
        return null;
    }

    public int getNumberOfFreeSeats() {
        int counter = 0;
        for(int i = 0; i < seats.size(); i++) {
            if(!seats.get(i).isOccupied()) {
                counter++;
            }
        }
        return counter;
    }

    public void sitOnSeat(int seatNumber) {
        for(int i = 0; i < seats.size(); i++) {
            if(seats.get(i).seatNumber == seatNumber) {
                seats.get(i).occupy();
            }
        }
    }

    public void leaveSeat(int seatNumber) {
        for(int i = 0; i < seats.size(); i++) {
            if(seats.get(i).seatNumber == seatNumber) {
                seats.get(i).leave();
            }
        }
    }

    public String toString() {
        String s = "";
        for(int i = 0; i < seats.size(); i++) {
            s += seats.get(i).toString() + "\n";
        }
        return s;
    }
}
