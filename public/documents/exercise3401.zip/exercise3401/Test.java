package exercise3401;

public class Test {
    public static void main(String[] args) {
        Seat s1 = new Seat(139856);
        Seat s2 = new Seat(403895);
        Seat s3 = new Seat(310475);
        Seat s4 = new Seat(127859);

        Seat[] seats = new Seat[3];
        seats[0] = s1;
        seats[1] = s2;
        seats[2] = s3;

        Bus bus = new Bus(seats);
        int i = bus.getNumberOfSeats();
        System.out.println(i == 3);
        Seat s = bus.getSeat(403895);
        System.out.println(s == s2);
        bus.sitOnSeat(139856);
        bus.sitOnSeat(310475);
        int j = bus.getNumberOfFreeSeats();
        System.out.println(j == 1);
        bus.leaveSeat(139856);
        int k = bus.getNumberOfFreeSeats();
        System.out.println(k == 2);
        bus.replaceSeat(403895, s4);
        System.out.println(bus);
    }
}
