package exercise3402;

public class Bus {
    private Seat[] seats;

    public Bus(Seat[] seats) {
        this.seats = seats;
    }

    public int getNumberOfSeats() {
        return seats.length;
    }

    /* the main idea for this method is to replace the seat with the given seatNumber,
     * remember this is to be seen as the id of that specific seat, not the order
     * the seats have in the bus, so we first need to find the given seat, then
     * replace it.
     */
    public void replaceSeat(int seatNumber, Seat seat) {
        for(int i = 0; i < seats.length; i++) {
            if(seats[i].seatNumber == seatNumber) {
                seats[i] = seat;
            }
        }
    }

    public Seat getSeat(int seatNumber) {
        for(int i = 0; i < seats.length; i++) {
            if(seats[i].seatNumber == seatNumber) {
                return seats[i];
            }
        }
        return null;
    }

    public int getNumberOfFreeSeats() {
        int counter = 0;
        for(int i = 0; i < seats.length; i++) {
            if(!seats[i].isOccupied()) {
                counter++;
            }
        }
        return counter;
    }

    public void sitOnSeat(int seatNumber) {
        for(int i = 0; i < seats.length; i++) {
            if(seats[i].seatNumber == seatNumber) {
                seats[i].occupy();
            }
        }
    }

    public void leaveSeat(int seatNumber) {
        for(int i = 0; i < seats.length; i++) {
            if(seats[i].seatNumber == seatNumber) {
                seats[i].leave();
            }
        }
    }

    public String toString() {
        String s = "";
        for(int i = 0; i < seats.length; i++) {
            s += seats[i].toString() + "\n";
        }
        return s;
    }
}
