package exercise3402;

public class Seat {
    public int seatNumber;
    private boolean occupied;

    public Seat(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public void occupy() {
        occupied = true;
    }

    public void leave() {
        occupied = false;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String toString() {
        String s = "seat number: " + seatNumber;
        return s;
    }
}
