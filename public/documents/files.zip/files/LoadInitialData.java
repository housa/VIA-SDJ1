package files;

import java.io.*;

public class LoadInitialData {

	public static void main(String[] args) {
		
		StudentList students = new StudentList();
		MyTextFileIO mtfio = new MyTextFileIO();
		String[] arrayFromFile = null;
		
		try {
			arrayFromFile = mtfio.readArrayFromFile("students.txt");
			
			for(int i = 0; i < arrayFromFile.length; i++) {
				String line = arrayFromFile[i];
				String[] temp = line.split(",");
				String firstName = temp[0];
				String lastName = temp[1];
				String country = temp[2];
				
				Student student = new Student(firstName, lastName, country);
				students.add(student);
			}
		}
		catch (FileNotFoundException e) {
			
		}
		
		MyFileIO mfio = new MyFileIO();
		
		try {
		    mfio.writeToFile("students.bin", students);
		  }
		  catch (FileNotFoundException e) {
		    System.out.println("Error opening file ");
		  }
		  catch (IOException e) {
		    System.out.println("IO Error writing to file ");
		  }
		  
		System.out.println("Done");
	}
}
