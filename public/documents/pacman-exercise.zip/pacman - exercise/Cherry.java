import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Cherry can not move.
 * 
 * @Alexandra Hou
 * @version 1, 26-10-16
 */
public class Cherry extends Actor
{
    /**
     * Cherry is not moving. It is just hoping that pacman 
     * doesn't find it.
     */
    public void act() 
    {
        //Hope not to be found!
    }    
}
