import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ghosts sole purpose in life is to kill Pacman and thereby protect their presious cheese. 
 * They move random around the labyrinth, while looking for a chance to kill Pacman. 
 * 
 * @Camilla Marie Vinther Frederiksen 
 * @version 2, 01-10-2016
 */
public class Ghost extends MoveAbleActor
{  
    /**
     * Act - move randomly around the world without colliding with the walls. 
     * If seeing Pacman, then kill him.
     */
    public void act() {
        moveRandom();
        killPacman();
    }    
        
    /**
     * If catching Pacman, then kill him and end the game!
     */
    private void killPacman() {
        //Write some code here that will kill pacman!
    }
}
