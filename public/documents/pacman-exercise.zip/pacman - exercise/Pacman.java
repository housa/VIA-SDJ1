import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pacman can move around in the labyrinth, but cannot go through the walls.
 * He loves cheese, and therefore tries to eat it. 
 * He hates ghosts as he will die if they touch him. 
 * He is controlled by the users key-presses. 
 * 
 * @Camilla Marie Vinther Frederiksen 
 * @version 2, 01-10-2016
 */
public class Pacman extends MoveAbleActor {
    private int currentDirection = 0;
    
    /**
     * Act - do whatever the Pacman wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
        checkForKeyPressAndMove();
        eatCheese();
        eatCherry();
    }    
    
    /**
     * This method checks wether the user has pressed a key that controls Pacman, 
     * and if so rotates Pacman and moves him in that direction.
     */
    private void checkForKeyPressAndMove() {
        //Write code here to make pacman move in correct direction whenever the user presses a key
    }
    
    /**
     * This method removes all pieces of cheese from the world, if Pacman is touching them.
     * Furthermore it checks if the game is done.
     */
    private void eatCheese() {
        //Write code here to make cheese disappear whenever pacman bumps into it
    }
    
    /**
     * This method removes all pieces of cherry from the world, if Pacman is touching them.
     */
    private void eatCherry() {
        removeTouching(Cherry.class);
    }
}
