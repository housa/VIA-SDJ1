import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Walls are static objects that no actor can pass through
 * 
 * @Camilla Marie Vinther Frederiksen 
 * @version 2, 01-10-2016
 */
public class Wall extends Actor
{
    /**
     * A Wall is just standing there.
     */
    public void act() 
    {
        //Do nothing
    }    
}
