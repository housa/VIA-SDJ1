import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Cheese can not move
 * 
 * @Camilla Marie Vinther Frederiksen 
 * @version 2, 01-10-2016
 */
public class Cheese extends Actor
{
    /**
     * Cheese is not moving. It is just hoping that pacman 
     * doesn't find it.
     */
    public void act() 
    {
        //Hope not the be found!
    }    
}
