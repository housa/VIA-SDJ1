import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Sets up the labyrinth with cheeses, ghosts and a pacman.
 * 
 * @Camilla Marie Vinther Frederiksen 
 * @version 2, 01-10-2016
 */
public class Labyrinth extends World
{
    private static int WALL_WIDTH = 30;
    private static int WALL_HEIGHT = 30;

    /**
     * Constructs a labyrinth with a maze of walls, lots of cheeses, some ghosts
     * and a pacman.
     */
    public Labyrinth(){    
        super(WALL_WIDTH * 26, WALL_HEIGHT * 20, 1); 
        addMaze();
        addCheeseEveryWhere();
        addCherrySomewhere();
        addGhosts();
        addPacman();
        prepare();
    }

    /**
     * Creates a map of where to place walls into the world.
     * 
     * @return  An array of arrays of 1's and 0's where 1's symbolize walls.
     */
    private int[][] getLabyrinthMap() {
        int[][] labyrinth = {
                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
                {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
                {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
                {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
                {1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
                {1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1}, 
                {1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 1}, 
                {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1}, 
                {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
                {1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1}, 
                {1, 1, 1, 1, 1, 1, 0, 1, 0, 2, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1}, 
                {1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1},
                {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1}, 
                {1, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1},
                {1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1},            
                {1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1},            
                {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
                {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
            };

        return labyrinth; 
    }

    /**
     * Adds walls into this world.
     */
    private void addMaze() {    
        int[][] wallMap = getLabyrinthMap();
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 25; j++) {
                if (wallMap[i][j] == 1) {
                    addObject(getWallInCorrectSize(), (j + 1) * WALL_WIDTH, (i + 1) * WALL_HEIGHT); 
                }
            }
        }
    }

    /**
     * Creates walls in a size that fits with the worlds dimensions.
     * 
     * @return  A wall instance in a size that fits this world
     */
    private Wall getWallInCorrectSize() {
        Wall wall = new Wall();
        wall.getImage().scale(WALL_WIDTH, WALL_HEIGHT);
        return wall;
    }

    /**
     * Add cheeses to the world where there is no wall.
     */
    private void addCheeseEveryWhere() {
        int[][] cheeseMap = getLabyrinthMap();
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 25; j++) {
                if (cheeseMap[i][j] == 0) {
                    addObject(getCheeseInCorrectSize(), (j + 1) * WALL_WIDTH, (i + 1) * WALL_HEIGHT); 
                }
            }
        }
    }

    /**
     * Creates cheeses in a size that fits with the worlds dimensions.
     * 
     * @return  A cheese instance in a size that fits this world
     */
    private Cheese getCheeseInCorrectSize() {
        Cheese cheese = new Cheese();
        cheese.getImage().scale(15, 15);
        return cheese;
    }

    /**
     * Add cherrys to the world where there is a 2.
     */
    private void addCherrySomewhere() {
        int[][] cherryMap = getLabyrinthMap();
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 25; j++) {
                if (cherryMap[i][j] == 2) {
                    addObject(getCherryInCorrectSize(), (j + 1) * WALL_WIDTH, (i + 1) * WALL_HEIGHT); 
                }
            }
        }
    }

    /**
     * Creates cherries in a size that fits with the worlds dimensions.
     * 
     * @return  A cheese instance in a size that fits this world
     */
    private Cherry getCherryInCorrectSize() {
        Cherry cherry = new Cherry();
        cherry.getImage().scale(15, 15);
        return cherry;
    }
    
    /**
     * Adds four ghosts to the world.
     */
    private void addGhosts() {
        int[][] ghostMap = {{4, 5}, {4, 16}, {22, 5}, {22, 16}};

        for (int i = 0; i < 4; i++) {
            addObject(getGhostInCorrectSize(), ghostMap[i][0] * WALL_WIDTH, ghostMap[i][1] * WALL_HEIGHT); 
        }
    }

    /**
     * Creates ghosts in a size that fits with the worlds dimensions
     * 
     * @return  A ghost instance in a size that fits this world
     */
    private Ghost getGhostInCorrectSize() {
        Ghost ghost = new Ghost();
        ghost.getImage().scale(WALL_WIDTH - 6, WALL_HEIGHT - 6);
        return ghost;
    }

    /**
     * Adds one Pacman in dimensions that fits the world.
     */
    private void addPacman() {
        Pacman pacman = new Pacman();
        pacman.getImage().scale(WALL_WIDTH - 6, WALL_HEIGHT - 6);
        addObject(pacman, 13 * WALL_WIDTH, 14 * WALL_HEIGHT);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
