import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;

/**
 * Write a description of class TextImage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TextImage extends Actor
{    
   public TextImage(String text, int size) {
        setImage(new GreenfootImage(text, size, Color.white, null, Color.darkGray));    
   }
}
