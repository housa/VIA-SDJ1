
public class CourseTest {
	
	public static void main(String[] args) {
		Course course1 = new Course();
		Course course2 = new Course("DIM", 20, true);
		Course course3 = new Course("MOB", false);
		
		course1.setNumberOfStudents(10);
		course1.setName("Godt kursus");
		course2.setElectiveCourse(false);
		
		System.out.println(course1.toString());
		System.out.println(course2.toString());
		System.out.println(course3.toString());
	}
}
