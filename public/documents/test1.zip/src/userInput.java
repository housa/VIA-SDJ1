import java.util.Scanner;

public class userInput {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Type an integer: ");
		int first = scanner.nextInt();
		System.out.print("Type a second integer: ");
		int second = scanner.nextInt();
		System.out.print("Type a third integer: ");
		int third = scanner.nextInt();
		scanner.close();
		
		System.out.println("The product of (" + first + " * " + second + ") is " + (first * second));
		System.out.println("The sum of (" + first + " + " + second + ") is " + (first + second));
		System.out.println("The quotient of (" + second + " / " + third + ") is " + ((double)second / (double)third));
		System.out.println("The difference of (" + second + " - " + third + ") is " + (second - third));
	}
}
